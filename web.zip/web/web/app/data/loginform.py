class LoginForm(FlaskForm):
    username = UsernameField('логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    submit = SubmitField('Войти')
