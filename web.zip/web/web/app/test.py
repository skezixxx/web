from flask import Flask, render_template, url_for, request, redirect, jsonify
from data import db_session
from data.users import User
from flask_login import LoginManager, login_user, logout_user
from werkzeug.security import generate_password_hash, check_password_hash
import random


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
IS_CONNECTED = 0
login = str
login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)



@app.route('/', methods=['POST', 'GET'])
def mainweb():
    global IS_CONNECTED, login
    error = ''
    result = None
    if request.method == 'POST':
        try:
            min_num = int(request.form['min'])
            max_num = int(request.form['max'])
            count = int(request.form['count'])
            unique = 'unique' in request.form
            cusnum = request.form['cusnum']

            if cusnum:
                numbers = [int(i.strip()) for i in cusnum.split(',')]
                result = random.sample(numbers, count) if unique else random.choices(numbers, k=count)
            else:
                if unique and (max_num - min_num + 1) < count:
                    error = 'Недостаточно уникальных чисел в диапазоне'
                else:
                    if unique:
                        result = []
                        numbers_range = list(range(min_num, max_num + 1))
                        col = 0
                        for i in numbers_range.copy():
                            if col == count:
                                break
                            else:
                                rand = random.choice(numbers_range)
                                result.append(rand)
                                numbers_range.remove(rand)
                            col += 1
                    else:
                        result = []
                        for i in range(count):
                            random_number = random.randint(min_num, max_num)
                            result.append(random_number)
        except ValueError:
            error = 'Ошибка ввода данных'
    return render_template('mainweb.html', result=result, error=error, IS_CONNECTED=IS_CONNECTED, login=login)


@app.route('/log', methods=['POST', 'GET'])
def log():
    global IS_CONNECTED, login
    if request.method == 'GET':
        return render_template('log.html', title='Вход', username_password='', IS_CONNECTED=IS_CONNECTED, login=login)
    db_sess = db_session.create_session()
    try:
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)
        print(1)
        user = db_sess.query(User).filter(User.username == username).first()
        if user and check_password_hash(user.hashed_password, password):
            login_user(user)
            IS_CONNECTED = 1
            login = user.username
            return redirect(url_for('mainweb'))
        else:
            return render_template('log.html', 
                                 title='Вход', 
                                 username_password='Неверный логин или пароль', IS_CONNECTED=IS_CONNECTED, login=login )
    except Exception as e:
        return render_template('log.html', 
                             title='Вход', 
                             username_password='Ошибка сервера', IS_CONNECTED=IS_CONNECTED, login=login)
    

@app.route('/reg', methods=['POST', 'GET'])
def reg():
    if request.method == 'GET':
        return render_template('reg.html', title='Регистрация', chipsi='', IS_CONNECTED=IS_CONNECTED, login=login)
    elif request.method == 'POST':
        try:
            user = User()
            user.username = request.form['username']
            user.hashed_password = f"{generate_password_hash(request.form['password'])}"    
            db_sess = db_session.create_session()
            db_sess.add(user)
            db_sess.commit()
            return redirect(url_for('log'), 301)
        except Exception:
            return render_template('reg.html', title='Регистрация', chipsi='Упс, этот логин уже занят!', IS_CONNECTED=IS_CONNECTED, login=login)

@app.errorhandler(404)
def not_found(e):
  return render_template("404.html")


def main():
    db_session.global_init("db/blogs.db")
    app.run()


@app.route('/logout')
def logout():
    global IS_CONNECTED, login
    IS_CONNECTED = 0
    login = ""
    logout_user()
    return redirect('/')


@app.errorhandler(403)
def forbidden(error):
    return jsonify(error="403 Forbidden", message="Страница недоступна"), 403


@app.errorhandler(404)
def not_found(error):
    return jsonify(error="404 Not Found", message="Запрашиваемый ресурс не найден на сервере."), 404


@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify(error="405 Method Not Allowed", message="Метод запроса не поддерживается для данного ресурса."), 405


@app.errorhandler(406)
def not_acceptable(error):
    return jsonify(error="406 Not Acceptable", message="Сервер не может предоставить данные в формате."), 406


@app.errorhandler(408)
def request_timeout(error):
    return jsonify(error="408 Request Timeout", message="Время ожидания запроса истекло, сервер не получил полный запрос."), 408


@app.errorhandler(409)
def conflict(error):
    return jsonify(error="409 Conflict", message="Запрос конфликтует с текущим состоянием сервера."), 409


@app.errorhandler(410)
def gone(error):
    return jsonify(error="410 Gone", message="Запрашиваемый ресурс был удалён."), 410


@app.errorhandler(412)
def precondition_failed(error):
    return jsonify(error="412 Precondition Failed", message="Условие в заголовках запроса оказалось ложным."), 412


@app.errorhandler(413)
def payload_too_large(error):
    return jsonify(error="413 Payload Too Large", message="Размер нагрузки запроса слишком велик."), 413


@app.errorhandler(414)
def uri_too_long(error):
    return jsonify(error="414 URI Too Long", message="URI запроса слишком длинный"), 414


@app.errorhandler(415)
def unsupported_media_type(error):
    return jsonify(error="415 Unsupported Media Type", message="Тип данных запроса не поддерживается сервером."), 415


@app.errorhandler(416)
def range_not_satisfiable(error):
    return jsonify(error="416 Range Not Satisfiable", message="Запрошенный диапазон данных не может быть предоставлен."), 416


@app.errorhandler(417)
def expectation_failed(error):
    return jsonify(error="417 Expectation Failed", message="Сервер не может выполнить ожидания."), 417


@app.errorhandler(422)
def unprocessable_entity(error):
    return jsonify(error="422 Unprocessable Entity", message="Сервер не может обработать инструкции."), 422


@app.errorhandler(423)
def locked(error):
    return jsonify(error="423 Locked", message="Ресурс заблокирован."), 423


@app.errorhandler(424)
def failed_dependency(error):
    return jsonify(error="424 Failed Dependency", message="Запрос не выполнен из-за неудачного предыдущего запроса."), 424


@app.errorhandler(428)
def precondition_required(error):
    return jsonify(error="428 Precondition Required", message="Для выполнения запроса необходимо предусловие."), 428


@app.errorhandler(429)
def too_many_requests(error):
    return jsonify(error="429 Too Many Requests", message="Слишком много запросов."), 429


@app.errorhandler(431)
def request_header_fields_too_large(error):
    return jsonify(error="431 Request Header Fields Too Large", message="Поля заголовка запроса слишком большие."), 431


@app.errorhandler(451)
def unavailable_for_legal_reasons(error):
    return jsonify(error="451 Unavailable For Legal Reasons", message="Доступ к ресурсу запрещён"), 451


@app.errorhandler(500)
def internal_server_error(error):
    return jsonify(error="500 Internal Server Error", message="Внутренняя ошибка сервера."), 500


@app.errorhandler(501)
def not_implemented(error):
    return jsonify(error="501 Not Implemented", message="Сервер не поддерживает данную функцию."), 501


@app.errorhandler(502)
def bad_gateway(error):
    return jsonify(error="502 Bad Gateway", message="Плохой шлюз - сервер получил неверный ответ."), 502


@app.errorhandler(503)
def service_unavailable(error):
    return jsonify(error="503 Service Unavailable", message="Сервис временно недоступен, попробуйте позже."), 503


@app.errorhandler(504)
def gateway_timeout(error):
    return jsonify(error="504 Gateway Timeout", message="Шлюз не ответил вовремя."), 504


s@app.errorhandler(505)
def http_version_not_supported(error):
    return jsonify(error="505 HTTP Version Not Supported", message="Версия HTTP, используемая в запросе, не поддерживается сервером."), 505


if __name__ == '__main__':
    main()
