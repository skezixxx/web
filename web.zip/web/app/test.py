from flask import Flask, render_template, url_for, request

app = Flask(__name__)


@app.route('/', methods=['POST', 'GET'])
@app.route('/reg', methods=['POST', 'GET'])
def sign():
    return render_template('reg.html', title='Регистрация')

@app.route('/log', methods=['POST', 'GET'])
def log():
    if request.method == 'GET':
        return render_template('log.html', title='Вход')
    elif request.method == 'POST':
        print(request.form['username'])
        print(request.form['password'])
        return 'яйке'

@app.errorhandler(404)
def not_found(e):
  return render_template("404.html")

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
