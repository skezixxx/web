from flask import Flask, render_template, url_for, request, redirect
from data import db_session
from data.users import User
from flask_login import LoginManager, login_user, logout_user
from werkzeug.security import generate_password_hash, check_password_hash
import random


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
IS_CONNECTED = 0
login = str
login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)



@app.route('/', methods=['POST', 'GET'])
def mainweb():
    global IS_CONNECTED, login
    error = ''
    result = None
    if request.method == 'POST':
        try:
            min_num = int(request.form['min'])
            max_num = int(request.form['max'])
            count = int(request.form['count'])
            unique = 'unique' in request.form
            cusnum = request.form['cusnum']

            if cusnum:
                numbers = [int(i.strip()) for i in cusnum.split(',')]
                result = random.sample(numbers, count) if unique else random.choices(numbers, k=count)
            else:
                if unique and (max_num - min_num + 1) < count:
                    error = 'Недостаточно уникальных чисел в диапазоне'
                else:
                    if unique:
                        result = []
                        numbers_range = list(range(min_num, max_num + 1))
                        col = 0
                        for i in numbers_range.copy():
                            if col == count:
                                break
                            else:
                                rand = random.choice(numbers_range)
                                result.append(rand)
                                numbers_range.remove(rand)
                            col += 1
                    else:
                        result = []
                        for i in range(count):
                            random_number = random.randint(min_num, max_num)
                            result.append(random_number)
        except ValueError:
            error = 'Ошибка ввода данных'
    return render_template('mainweb.html', result=result, error=error, IS_CONNECTED=IS_CONNECTED, login=login)


@app.route('/log', methods=['POST', 'GET'])
def log():
    global IS_CONNECTED, login
    if request.method == 'GET':
        return render_template('log.html', title='Вход', username_password='', IS_CONNECTED=IS_CONNECTED, name=login)
    db_sess = db_session.create_session()
    try:
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)
        print(1)
        user = db_sess.query(User).filter(User.username == username).first()
        if user and check_password_hash(user.hashed_password, password):
            login_user(user)
            IS_CONNECTED = 1
            login = user.username
            return redirect(url_for('mainweb'))
        else:
            return render_template('log.html', 
                                 title='Вход', 
                                 username_password='Неверный логин или пароль', IS_CONNECTED=IS_CONNECTED, login=login )
    except Exception as e:
        return render_template('log.html', 
                             title='Вход', 
                             username_password='Ошибка сервера', IS_CONNECTED=IS_CONNECTED, name=login)
    

@app.route('/reg', methods=['POST', 'GET'])
def reg():
    if request.method == 'GET':
        return render_template('reg.html', title='Регистрация', chipsi='', IS_CONNECTED=IS_CONNECTED, name=login)
    elif request.method == 'POST':
        try:
            user = User()
            user.username = request.form['username']
            user.hashed_password = f"{generate_password_hash(request.form['password'])}"    
            db_sess = db_session.create_session()
            db_sess.add(user)
            db_sess.commit()
            return redirect(url_for('log'), 301)
        except Exception:
            return render_template('reg.html', title='Регистрация', chipsi='Упс, этот логин уже занят!', IS_CONNECTED=IS_CONNECTED, name=login)

@app.errorhandler(404)
def not_found(e):
  return render_template("404.html")


def main():
    db_session.global_init("db/blogs.db")
    app.run()


@app.route('/logout')
def logout():
    global IS_CONNECTED, login
    IS_CONNECTED = 0
    login = ""
    logout_user()
    return redirect('/')


if __name__ == '__main__':
    main()
